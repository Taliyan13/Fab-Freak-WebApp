#ifndef FIREBASE_SSL_CLIENT
#define FIREBASE_SSL_CLIENT

#if __has_include(<WiFiNINA.h>)
#include <WiFiNINA.h>
#elif __has_include(<WiFi101.h>)
#include <WiFi101.h>
#endif

#endif